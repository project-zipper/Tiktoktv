plugins {
    id("com.android.application")
}

android {
    namespace = "com.zipperos.tiktoktv"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.zipperos.tiktoktv"
        minSdk = 23
        targetSdk = 28
        versionCode = 1
        versionName = "1.0"
    }
}
