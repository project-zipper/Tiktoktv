package com.zipperos.tiktoktv;

import android.app.Activity;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

public class MainActivity extends Activity {
    private WebView webView;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        webView = new WebView(this);
        webView.setFocusable(true);
        webView.setFocusableInTouchMode(true);
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient());

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setSupportZoom(true);
        settings.setBuiltInZoomControls(false);
        settings.setLoadWithOverviewMode(true);
        settings.setUseWideViewPort(true);
        settings.setUserAgentString(settings.getUserAgentString()
                + " TikTokTVRemote/1.0");

        setContentView(webView);
        webView.loadUrl("https://www.tiktok.com/");
        webView.requestFocus();
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_BACK) {
            if (webView != null && webView.canGoBack()) {
                webView.goBack();
                return true;
            }
            return super.onKeyDown(keyCode, event);
        }

        String direction = null;
        switch (keyCode) {
            case KeyEvent.KEYCODE_DPAD_UP: direction = "ArrowUp"; break;
            case KeyEvent.KEYCODE_DPAD_DOWN: direction = "ArrowDown"; break;
            case KeyEvent.KEYCODE_DPAD_LEFT: direction = "ArrowLeft"; break;
            case KeyEvent.KEYCODE_DPAD_RIGHT: direction = "ArrowRight"; break;
            case KeyEvent.KEYCODE_DPAD_CENTER:
            case KeyEvent.KEYCODE_ENTER:
                webView.evaluateJavascript(
                    "(function(){var e=document.activeElement;if(e){e.click();}" +
                    "else {var x=document.elementFromPoint(innerWidth/2,innerHeight/2);" +
                    "if(x)x.click();}})()", null);
                return true;
        }
        if (direction != null) {
            webView.evaluateJavascript(
                "(function(k){" +
                "var a=[...document.querySelectorAll('a,button,input,[tabindex]:not([tabindex=\"-1\"])')]" +
                ".filter(e=>e.offsetWidth>0&&e.offsetHeight>0);" +
                "if(!a.length)return;" +
                "var i=a.indexOf(document.activeElement);" +
                "if(i<0)i=0;else i=(i+1)%a.length;" +
                "a[i].focus({preventScroll:false});" +
                "})(\"" + direction + "\")", null);
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }

    @Override
    protected void onDestroy() {
        if (webView != null) {
            webView.stopLoading();
            webView.destroy();
        }
        super.onDestroy();
    }
}
