# TikTok TV Remote (unofficial)

A small Android TV-launchable WebView wrapper for https://www.tiktok.com/ with basic D-pad/Enter/Back key handling. It does **not** include TikTok's source code or modify the official TikTok APK.

## Build the APK with GitHub Actions
1. Create a GitHub repository, for example `TikTokTV-Remote`.
2. Upload all files from this project, keeping the `.github/workflows/build.yml` path.
3. Open the repository's **Actions** tab.
4. Select **Build TikTok TV Remote APK** and press **Run workflow** (or push to `main`).
5. Open the completed run and download the `TikTokTV-Remote-debug-apk` artifact.
6. Extract the artifact ZIP to get `app-debug.apk`, then install it on your Android TV.

## Important limitations
- TikTok may block or display an awkward layout in TV WebView; TikTok is designed mainly for phones.
- Remote navigation is best-effort because TikTok's website can change its page structure.
- Login, playback, DRM, or regional restrictions may prevent some features from working.
- This is an unofficial wrapper and is not affiliated with TikTok. Use TikTok's service and terms normally.
- The APK is a debug build, not a Play Store release. Only install APKs you built or trust.
